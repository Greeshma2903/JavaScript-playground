'use strict';

// // manipute 'input' field using 'value'
// document.querySelector('.guess').value = 23;
// console.log(document.querySelector('.guess').value);

let score = 20;
let highestScore = 0;
let secretNumber = Math.floor(Math.random() * 20) + 1;

const userScore = document.querySelector('.score');
const userHighScore = document.querySelector('.highscore');
const number = document.querySelector('.number'); // '?'

function displayMssg(message) {
  document.querySelector('.message').textContent = message;
}

const checkGuess = document.querySelector('.check');

checkGuess.addEventListener('click', function () {
  let guess = Number(document.querySelector('.guess').value);

  // when there is no input
  if (!guess) {
    displayMssg('⛔ No Number!');

    // when player wins the game
  } else if (guess === secretNumber) {
    displayMssg('🎉Correct Answer!');
    document.querySelector('body').style.backgroundColor = '#069d06';
    number.style.width = '20rem';
    number.textContent = secretNumber;

    if (score > highestScore) {
      highestScore = score;
    }
    userHighScore.textContent = highestScore;

    // when guess is wrong
  } else if (guess !== secretNumber) {
    if (score > 1) {
      displayMssg(
        guess > secretNumber ? '❗ Guess is too high' : '❗ Guess is too low'
      );
      score--;
      userScore.textContent = score;
    } else {
      displayMssg('😬You lost the game!');
      userScore.textContent = 0;
    }
  }
});

const again = document.querySelector('.again');

again.addEventListener('click', function () {
  score = 20;
  secretNumber = Math.floor(Math.random() * 20) + 1;

  displayMssg('Start guessing...');
  number.textContent = '?';
  userScore.textContent = score;
  document.querySelector('.guess').value = '';

  document.querySelector('body').style.backgroundColor = '#222';
  number.style.width = '15rem';
});

//////////////////////////////////////
// Coding Challenge #1

/* 
Implement a game rest functionality, so that the player can make a new guess! Here is how:

1. Select the element with the 'again' class and attach a click event handler
2. In the handler function, restore initial values of the score and secretNumber variables
3. Restore the initial conditions of the message, number, score and guess input field
4. Also restore the original background color (#222) and number width (15rem)

GOOD LUCK 😀
*/
