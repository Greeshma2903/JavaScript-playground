'use strict';

// Data needed for first part of the section
const weekdays = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];

const openingHours = {
  [weekdays[3]]: {
    // * can now compute object property names
    open: 12,
    close: 22,
  },
  fri: {
    open: 11,
    close: 23,
  },
  sat: {
    open: 0, // Open 24 hours
    close: 24,
  },
};

const restaurant = {
  name: 'Classico Italiano',
  location: 'Via Angelo Tavanti 23, Firenze, Italy',
  categories: ['Italian', 'Pizzeria', 'Vegetarian', 'Organic'],
  starterMenu: ['Focaccia', 'Bruschetta', 'Garlic Bread', 'Caprese Salad'],
  mainMenu: ['Pizza', 'Pasta', 'Risotto'],

  order: function (starterIndex, mainIndex) {
    return [this.starterMenu[starterIndex], this.mainMenu[mainIndex]];
  },

  // enhanced ES6 features
  openingHours,

  // * parameter passed is destructured (!they are not multiple parameters)
  orderDelivery({ starterIndex = 1, mainIndex = 0, time = '20:00', address }) {
    console.log(
      `Order received! ${this.starterMenu[starterIndex]} and ${this.mainMenu[mainIndex]} will be delivered to ${address} at ${time}`
    );
  },

  // functions can also be written like this or like above
  showIng(ing1, ing2, ing3) {
    console.log(ing1, ing2, ing3);
  },

  orderPizza(mainIngredient, ...otherIngredients) {
    console.log(`main: ${mainIngredient}`);
    console.log(otherIngredients);
  },
};

// console.log(openingHours); // this gives the 1st property, tho not named directly
/* ---------------------------------------- 
// MAPS: FUNDAMENTALS
const rest = new Map();

rest.set('name', 'Italiano');
console.log(rest.set(1, 'Rome Italy')); // showa dynamically, ie. changes made later are also reflected
rest.set(2, 'Milan Italy');

rest
  .set('categories', ['Italian', 'Pizzeria', 'Vegetarian', 'Organic'])
  .set('open', 11)
  .set('close', 23)
  .set(true, 'We are open')
  .set(false, 'We are closed');

let time = 21;
// using maps keys
console.log(rest.get(time > rest.get('open') && time < rest.get('close')));

console.log( rest.has('categories'));
rest.delete(2);
// rest.clear();
console.log(rest.size);   // count no of keys/items

// * we can set arrays/objects as key values
const arr = [1,2];
rest.set(arr, "test");  // * directly writing array would make it un-usable

rest.set(document.querySelector('h1'), 'heading');

console.log(rest);
*/

/* ------------------------------------------ 
// MAPS: ITERATION
const question = new Map([
  ['question', 'What is the best programming language?'],
  [1, 'C'],
  [2, 'Java'],
  [3, 'JavaScript'],
  [true, 'Correct! 👏'],
  [false, 'Try again!'],
  ['correct', 3],
]);

console.log(question);

console.log(question.get('question'));
for(const [key, value] of question){
  if(typeof key === 'number')
    console.log(`Answer ${key}: ${value}`);
}
// let userAnswer = Number(prompt('Your answer:'));
let userAnswer = 3;
console.log(userAnswer);
console.log(question.get(userAnswer === question.get('correct')));

// convert Object to Map
const restHours = new Map(Object.entries(openingHours));
console.log(restHours);

// convert Map to arrays
console.log([...question]);
// console.log([...question.entries()]);
console.log([...question.values()]);
console.log([...question.keys()]);
*/

/**---------------------------------------- 
// SETS: for unique values

const orderSet = new Set(['Roti', 'Mixed', 'Paneer', 'Roti', 'Paneer']);
console.log(orderSet);

console.log(orderSet.size);
console.log(orderSet.has('Pizza'));
console.log(orderSet.has('Roti'));
console.log(orderSet.add('Naan'));
console.log(orderSet.add('Naan'));
orderSet.delete('Roti');
// orderSet.clear();
console.log(orderSet);
console.log(orderSet[9]); // undefined, not arrays

// * Sets are iterables
console.log("We have the following dishes:");
for(const item of orderSet)
  console.log(item);

// * Sets are used to find or work with unique values
const staff = ['Waiter', 'Chef', 'Waiter', 'Manager', 'Chef', 'Waiter'];
const uniqueStaff = [...new Set(staff)];  // Set to Array
console.log(uniqueStaff);

console.log(`The hotel has ${(new Set(staff)).size} staff members`);  // count unique values

console.log(new Set('greeshmamedam').size);   // unique alphabets
*/

/* ------------------------------------------ 
// LOOPING OBJECTS : OBJECT KEYS, VALUES & ENTRIES

// Property NAMES
// Remember Objects are not iterables, so we use object-methods. Here, Object.keys(objectName) make an array of keys/properties of the Object and thus the loop can iterate thru this array.

const properties = Object.keys(openingHours);
console.log(properties);

let openStr = `We open ${properties.length} a week: `;
for (const day of properties) {
  openStr += `${day}, `;
} 
console.log(openStr);

// Property VALUES
const values = Object.values(openingHours);
console.log(values);

// Property ENTIRES (useful to fetch both Name & Value of object properties)
const entries = Object.entries(openingHours);
for (const [day, {open, close}] of entries) {
  console.log(`On ${day} we open at ${open}, and close at ${close}`)  ;
}
*/

/* ------------------------------------------ 
// OPTIONAL CHAINING (?.)
// based on Nullish values: undefined and null

if (restaurant.openingHours.mon) console.log(restaurant.openingHours.mon.open);

// WITH optioning chaining
console.log(restaurant.openingHours.mon?.open); // undefined

const days = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];

for (const day of days) {
  console.log(`${day}: `);
  console.log(restaurant.openingHours[day]?.open ?? 'closed');
}

// on methods
console.log(restaurant.order?.(0, 1) ?? 'Method does not exist');
console.log(restaurant.orderRissotto?.(0, 1) ?? 'Method does not exist');

// on arrays * checks empty array
const users = [{ firstName: 'Greeshma', age: 18 }];
// const users = [];
console.log(users[0]?.firstName ?? 'User array empty');

if(users[0]) console.log(users[0].firstName);   // * without chaining
*/

/* ------------------------------------------ 
// LOOPING ARRAYS: FOR-OF LOOP

// * best for looping through array elements (where index doesnt matter)

const menu = [...restaurant.mainMenu, ...restaurant.starterMenu];
for (const item of menu) console.log(item);
// with indexing
for (const [i, item] of menu.entries()) console.log(`${i + 1}: ${item}`);

// console.log([...menu.entries()]);
*/

/*------------------------------------------ 
//// SHORT CIRCUITING USING (&&) (||)

console.log('----OR----');
console.log(3 || 'Jonas'); // 3
console.log('' || 'Jonas'); // Jonas
console.log(true || 0); // true
console.log(undefined || null); // null
console.log(undefined || 0);

// --practical example--
const guests1 = restaurant.numGuests ? restaurant.numGuests : 10;
console.log(guests1);
// using ||
restaurant.numGuests = 23;
const guest2 = restaurant.numGuests || 10;  // if 'numGuests' not defined, show 10
console.log(guest2);

// * probelem 👆: if the number of guests were actually 0, still would show 10

console.log('----AND----');
console.log(0 && 'nick'); // 0
console.log(7 && 'nick'); // 'nick;
console.log('hello' && 2 && null && 'color'); // null

// --practical example--
if (restaurant.orderPizza) restaurant.orderPizza('mushrooms', 'olives');
// using &&
restaurant.orderPizza && restaurant.orderPizza('mushrooms', 'cheese');

// * In a chain of OR || returns the first truthy value or the last one if no truthy value is found.
// * AND returns the first falsy value or the last value if none were found.
*/

/* ------------------------------------------
// NULLISH COALESCING OPERATOR (??)

// * Nullish values: null & undefined (NOT 0 or '')
restaurant.numGuests = 0;   
const guest2 = restaurant.numGuests ?? 10;  
console.log(guest2);

// if 'numGuests' not defined, show 10, if defined as '0' will show 0
*/

/* ------------------------------------------------- 
//// DESTRUCTURING ARRAYS

const arr = [1, 2, 3];

const a = arr[0];
const b = arr[1];
const c = arr[2];

// * better: not array, but a way to destructure
const [x, y, z] = arr;

console.log(a, b, c);
console.log(`Destructured array: ${x}, ${y}, ${z}`);
console.log(`Orginal array remains unaffected --- ${arr}`); // arrays remains unaffected tho

//  Switching variables thru destructuring
let [main, , secondary] = restaurant.categories; // to skip values, just leave a hole ,,
console.log(main, secondary);

// // * tradionally
// const temp = main;
// main = secondary;
// secondary = temp;
// console.log(main, secondary);

// * thru destructuring
[main, secondary] = [secondary, main];
console.log('Destructured version: ' + main + ' ' + secondary);

// Receiving data
const [starterCourse, mainCourse] = restaurant.order(2, 0);
console.log(`Destructured receiving: ${starterCourse}, ${mainCourse}`);
// console.log( restaurant.order(2, 0));

//  Destructuring Nested arrays
const nested = [2, 4, [8, 3]];
// const [i, , j] = nested;
// console.log(i, j);
const [i, , [j, k]] = nested;
console.log(i, j, k);

//  Assigning Default values
const [p = 1, q = 1, r = 1] = [8, 9];
console.log(p, q, r);
*/
/* ---------------------------------
//// DESTRUCTURING OBJECTS

restaurant.orderDelivery({
  time: '22:40',
  address: 'Varunapuri Goa',
  mainIndex: 2,
  starterIndex: 2,
});

restaurant.orderDelivery({
  address: 'Varunapuri Goa', // default values used
  starterIndex: 2,
});

console.log('------------');

const { name, openingHours, categories } = restaurant;
console.log(name, openingHours, categories);

// Variable names to objects
const {
  name: restaurantName,
  openingHours: timings,
  categories: tags,
} = restaurant;
console.log(restaurantName, timings, tags);

// Assigning default values to undefined objects
const { menu = [], starterMenu: starters = [] } = restaurant;
console.log(menu, starters);

// * Destructring objects and it's properties is very useful when dealing with third-party data such as APIs

// Mutating variables
let m = 111;
let n = 999;
const obj = { m: 23, n: 7, l: 14 };
// }
// const {a, b} = obj; --> cannot re-assign a & b like that
({ m, n } = obj);
console.log(m, n); // * wrap them in parathesis() to make work

// Nested objects
const { fri } = openingHours;
const {
  fri: { open: openingTime, close: closingTime },
} = openingHours;

console.log(fri);
console.log(openingTime, closingTime);
*/

/* ----------------------------------------- 
//// SPREAD OPERATOR

const arr = [5, 6, 7];

// const newBadArray = [1, 2, arr[0], arr[1], arr[2]];
// console.log(newBadArray);

// * better way
const newArray = [1, 2, ...arr];
console.log(newArray);

// Print array elements
console.log(...arr);

// * spread operator doesnt affect the array
console.log(arr);

// Shallow Copy array
const mainMenuCopy = [...restaurant.mainMenu];
console.log(restaurant.mainMenu, mainMenuCopy);

// Join 2 arrays
const completeMenu = [...restaurant.mainMenu, ...restaurant.starterMenu];
console.log(completeMenu);

// Passing arguments using (...)
const ingredients = ['carrot', 'pasta', 'sauce'];
restaurant.showIng(...ingredients);

// * from ES2018 (...) can also be used on Objects (tho they are not iterables)
const newRestaurant = {
  foundedBy: 'Maria Poso',
  ...restaurant,
  foundedIn: 1999,
};
console.log(newRestaurant);

// Shallow copy of Objects
const restaurantCopy = { ...restaurant };
restaurantCopy.name = 'Pizzo Lasta';
console.log(restaurantCopy, restaurant); // change in copy doesnt get reflected in original
*/

/* --------------------------- 
//// REST OPERATOR & REST PARAMETERS

// SPREAD when used on RIGHT of =
const arr = [1, 2, ...[3, 4, 5]];
console.log(arr);

// REST when used on LEFT of =
const [a, b, ...others] = [1, 2, 3, 4, 5];
console.log(a, b, others);

// spread & rest
const [pizza, , risotto, ...otherFood] = [
  ...restaurant.mainMenu,
  ...restaurant.starterMenu,
];
console.log(pizza, risotto, otherFood);

// Objects
const { sat, ...weekdays } = restaurant.openingHours;
console.log(sat, weekdays);

// REST parameters
function add(...numbers) {
  let sum = 0,
    i;
  for (i = 0; i < numbers.length; i++) {
    sum += numbers[i];
  }
}

// esp. for arbitrary no of arg
add(2, 3);
add(1, 45, 2, 3, 21, 4);
add(1, 3, 4);

add(...arr);  // prefer using REST over passing arrays, as it gives verstality

restaurant.orderPizza('capsicum', 'onions', 'sausage');
restaurant.orderPizza('cheese');
*/

/** ---------------------------------------- 
// WORKING WITH STRINGS

const airline = 'Air Indigo';
const plane = 'A380';

console.log(airline);
console.log(airline.length);
console.log('B733'.length);

console.log(airline.indexOf('i')); // follows 0 indexing
console.log(airline.lastIndexOf('i'));
console.log('B733'.indexOf('3'));

// SLICING STRINGS : slice(startPos, endPos+1);
console.log(airline.slice(2));
console.log(airline.slice(0, 6)); // Air In -> till (6-1)th element

console.log('Air India'.slice(-3)); // slicing from right
console.log(airline.slice(1, -1)); // slices from start and end of string

console.log(airline.slice(0, airline.indexOf(' '))); // to print first word in string
console.log(airline.slice(airline.lastIndexOf(' ') + 1)); // to print last word in string

const checkMiddleSeat = function (seat) {
  // seats ending with B or E are middle seats
  let s = seat.slice(-1);
  if (s === 'B' || s === 'E') console.log('You got middle seat :/');
  else console.log('You got lucky ;)');
};

checkMiddleSeat('11B');
checkMiddleSeat('3E');
checkMiddleSeat('10F');

// BTS OF STRING METHODS
console.log(new String('Greeshma'));
console.log(typeof new String('Greeshma'));

// * most of these string methods are case-sensitive

// CHANGING CASE
const airline = 'Air Indigo';
console.log(airline.toLowerCase());
console.log(airline.toUpperCase());

// Fixed capitalization of strings
const myName = 'greEsHma';
const correctName = myName[0].toUpperCase() + myName.slice(1).toLowerCase();
console.log(correctName);

// Comparing emails
const email = 'hello@greeshma.so';
const loginEmail = '  Hello@Greeshma.SO \n';

const normalizedEmail = loginEmail.toLowerCase().trim();
if (email === normalizedEmail) console.log('User autheticated ✔');
else console.log('User email incorrect ❌');

// REPLACING
const priceIN = '290.90Rs';
const priceUS = priceIN.replace('Rs', '$');
console.log(priceUS);

const announcement =
  'All passengers come to boarding door 12. Boarding door 12!';
console.log(announcement.replace('door', 'gate')); // new string created, actual doesn't get affected; Not all occurances get affected
console.log(announcement.replaceAll('door', 'gate'));
// or use regex exp
console.log(announcement.replace(/door/g, 'gate'));

// BOOLEANS: include() , startsWith(), endsWith()
const planeName = 'Airbus 320Bneo';
console.log(planeName.includes('320'));

if (
  planeName.includes('320') &&
  planeName.startsWith('Air') &&
  planeName.endsWith('neo')
)
  console.log('The plane is part of the NEW Airbus 320 family');

// example
const checkBaggage = function (item) {
  let baggage = item.toLowerCase();
  if (baggage.includes('sword') || baggage.includes('rotten'))
    console.log('You are not allowed on board.');
  else console.log('Welcome aboard!');
};

checkBaggage("I have some rotten apples for making wine at my Grandma's");
checkBaggage("I have socks, a wand and Griffindor's sword");
checkBaggage('I have some chocolate and books');

// SPILTING & JOINING
console.log('a+very+long+string'.split('+')); // splits at dividor here(+) and stores values in array
console.log('Medam Greeshma'.split(' '));
const [firstName, lastName] = 'Medam Greeshma'.split(' ');

console.log(['Ms.', firstName, lastName].join(' '));

// caplitalization using Split/Join
function capitalizeName(theName) {
  const names = theName.split(' ');
  const namesUpper = [];
  for (const item of names) {
    // namesUpper.push(item[0].toUpperCase() + item.slice(1).toLowerCase());
    namesUpper.push(item.toLowerCase().replace(item[0], item[0].toUpperCase()));
  }

  console.log(namesUpper.join(' '));
}

capitalizeName('jessica ann smith davis');

// PADDING STRINGS
console.log('My name is Greeshma'.padStart(25, '-').padEnd(30, '-'));
console.log('Test'.padStart(25, '-').padEnd(30, '-'));

// practice
const maskNumber = function (number) {
  const str = String(number); // OR str = number + '';
  return str.slice(-4).padStart(str.length, 'X');
};

console.log(maskNumber(3829389));
console.log(maskNumber(823823121988));

// REPEATING STRINGS
console.log('All planes are delayed due to bad weather... '.repeat(7));

// CONCATNATING STRINGS
const str1 = 'Hello';
const str2 = 'World';

console.log(str1.concat(' ', str2));
// "Hello World"
*/
