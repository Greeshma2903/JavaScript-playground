'use strict';

/////////////////////////////////////////////////
/////////////////////////////////////////////////
// BANKIST APP

// Data
const account1 = {
  owner: 'Jonas Schmedtmann',
  movements: [200, 450, -400, 3000, -650, -130, 70, 1300],
  interestRate: 1.2, // %
  pin: 1111,
};

const account2 = {
  owner: 'Jessica Davis',
  movements: [5000, 3400, -150, -790, -3210, -1000, 8500, -30],
  interestRate: 1.5,
  pin: 2222,
};

const account3 = {
  owner: 'Steven Thomas Williams',
  movements: [200, -200, 340, -300, -20, 50, 400, -460],
  interestRate: 0.7,
  pin: 3333,
};

const account4 = {
  owner: 'Sarah Smith',
  movements: [430, 1000, 700, 50, 90],
  interestRate: 1,
  pin: 4444,
};

const accounts = [account1, account2, account3, account4];

// Elements
const labelWelcome = document.querySelector('.welcome');
const labelDate = document.querySelector('.date');
const labelBalance = document.querySelector('.balance__value');
const labelSumIn = document.querySelector('.summary__value--in');
const labelSumOut = document.querySelector('.summary__value--out');
const labelSumInterest = document.querySelector('.summary__value--interest');
const labelTimer = document.querySelector('.timer');

const containerApp = document.querySelector('.app');
const containerMovements = document.querySelector('.movements');

const btnLogin = document.querySelector('.login__btn');
const btnTransfer = document.querySelector('.form__btn--transfer');
const btnLoan = document.querySelector('.form__btn--loan');
const btnClose = document.querySelector('.form__btn--close');
const btnSort = document.querySelector('.btn--sort');

const inputLoginUsername = document.querySelector('.login__input--user');
const inputLoginPin = document.querySelector('.login__input--pin');
const inputTransferTo = document.querySelector('.form__input--to');
const inputTransferAmount = document.querySelector('.form__input--amount');
const inputLoanAmount = document.querySelector('.form__input--loan-amount');
const inputCloseUsername = document.querySelector('.form__input--user');
const inputClosePin = document.querySelector('.form__input--pin');

///////////////////////////////
// FUNCTIONS

const displayMovements = function (movements) {
  containerMovements.innerHTML = '';

  movements.forEach(function (mov, i) {
    const type = mov > 0 ? 'deposit' : 'withdrawal';

    let html = `<div class="movements__row">
      <div class="movements__type movements__type--${type}">${
      i + 1
    } ${type}</div>
      <div class="movements__value">${mov}</div>
    </div>`;

    containerMovements.insertAdjacentHTML('afterbegin', html);
  });
};

const calcDisplayBalance = function (movements) {
  const balance = movements.reduce((acc, cur) => acc + cur, 0);
  labelBalance.textContent = `${balance} EUR`;
};

const calcDisplaySummary = function (acc) {
  const incomes = acc.movements
    .filter(mov => mov > 0)
    .reduce((acc, mov) => acc + mov, 0);
  labelSumIn.textContent = `${incomes}€`;

  const out = acc.movements
    .filter(mov => mov < 0)
    .reduce((acc, mov) => acc + mov, 0);
  labelSumOut.textContent = `${Math.abs(out)}€`;

  const interest = acc.movements
    .filter(mov => mov > 0)
    .map(deposit => (deposit * acc.interestRate) / 100)
    .filter((int, i, arr) => {
      // console.log(arr);
      return int >= 1;
    })
    .reduce((acc, int) => acc + int, 0);
  labelSumInterest.textContent = `${interest}€`;
};

const createUsernames = function (accs) {
  accs.forEach(function (acc) {
    acc.username = acc.owner
      .toLowerCase()
      .split(' ')
      .map(name => name[0])
      .join('');
  });
};

// FUNCTION CALLS
displayMovements(account1.movements);
createUsernames(accounts);

calcDisplayBalance(account1.movements);
calcDisplaySummary(account1);
/////////////////////////////////////////////////
/////////////////////////////////////////////////
// LECTURES

const currencies = new Map([
  ['USD', 'United States dollar'],
  ['EUR', 'Euro'],
  ['GBP', 'Pound sterling'],
]);

const movements = [200, 450, -400, 3000, -650, -130, 70, 1300];
/////////////////////////////////////////////////

/** --------------------------------------- 
// SIMPLE ARRAY METHODS

// SLICE
console.log("SLICE ------------------");
const arr = ['a', 'b', 'c', 'd', 'e', 'f'];
console.log(arr.slice(2));
console.log(`Original array: ${arr}`);
console.log(arr.slice(-1));
console.log(arr.slice(1, -2));

// SPLICE
// console.log(arr.splice(2));   // shows deleted elements
console.log("SPLICE -----------------");
console.log(arr);
console.log(`Deleted: ${arr.splice(-1)}`);
console.log(`Original array: ${arr}`);
arr.splice(1, 2);
console.log(arr);
*/

/** ------------------------------------- 
// forEach

// forEach is used to (usually) loop over array elements
// Syntax: array.forEach(function (currentEle, index, array) {...});
// * forEach loop cannot be broken out of compared to other ways of looping


// using for..of
for (const [i, movement] of movements.entries()) {
  if (movement > 0) {
    console.log(`Movement ${i + 1}: You deposited ${movement}`);
  } else {
    console.log(`Movement ${i + 1}: You withdrew ${Math.abs(movement)}`);
  }
}

console.log('----------FOR EACH-----------');
// 0: function(200)
// 1: function(450)
// 2: function(-400)
*/

/** -------------------------------------- 
////////// map METHOD

const eurToUSD = 1.1;

const movementsUSD = movements.map(mov => Math.round(eurToUSD * mov));
console.log(movements);
console.log(movementsUSD);

// 'map' method gives access to the value, index and array in each loop
const movementDesc = movements.map((mov, i) => 
  `Movement ${i + 1}: You ${mov > 0 ? 'deposted' : 'withdrew'} ${mov}`
);

console.log(movementDesc);
*/
/*
// -- this doesn't work, cause forEach creates side effects, doesn't return values to form array --->
const movDesc = movements.forEach(function (mov, i, arr) {
  if (mov > 0) {
    return `Movement ${i + 1}: You deposited ${mov}`;
  } else {
    return `Movement ${i + 1}: You withdrew ${Math.abs(mov)}`;
  }
});
console.log(movDesc);
*/

/*
////////// filter METHOD
const deposits = movements.filter(function (mov) {
  return mov > 0;
});

console.log(deposits);

const withdrawals = movements.filter(mov => mov < 0);
console.log(withdrawals);

////////// reduce METHOD

// returns the computed value of operations
// accumulator -> SNOWBALL
// * we can set base value for accumulator

const globalBalance = movements.reduce(function (acc, cur, i, arr) {
  // console.log(`Iterator ${i}: ${acc}`);
  return acc + cur;
}, 0);

console.log(globalBalance);

const max = movements.reduce((acc, cur) => {
  if (cur > acc) {
    acc = cur;
  }
  return acc;
}, movements[0]);

console.log(max);

////////// Chaining Methods:: PIPELINE

const eurToUSD = 1.1;
const movToUSD = movements
  .filter(mov => mov > 0)
  .map(function (mov, i, arr) {
    // console.log(arr);
    return mov * eurToUSD;
  })
  .reduce((acc, cur) => acc + cur, 0);

console.log(movToUSD);

////////////// find METHOD

// find method is used to find the first occurence of an element in  an array
// it requires a callback function (just like other methods)
// returns a value (not array, compared to filter method)

const firstWithdrawal = movements.find(mov => mov < 0);
console.log(firstWithdrawal);

const account = accounts.find(acc => acc.pin === 2222);
console.log(account);

// 'find' is usually used when required to find a single (/specific) value

/////////// findIndex METHOD

console.log(movements);
movements.splice(2, 1);
console.log(movements);

/////////// sorting Arrays

//// Strings
const names = ['james', 'charles', 'megan', 'jenna'];
names.sort();
console.log(names);

// in-built sort function sorts based on strings
// it mutates original strings

//// Numbers
// return < 0, prev, next (keep order)
// return > 0, prev, next (change order)

// --> ascending
// movements.sort((prev, next) => {
//   if (prev > next) return 1;
//   else if (next > prev) return -1;
// }); 

movements.sort((prev, next) => prev - next);
console.log(movements);

// --> descending
movements.sort((prev, next) => next - prev);
console.log(movements);


///////////// ways to Fill arrays

//// array.fill(value, start, end);
const emptyArr = new Array(7);
console.log(emptyArr);
emptyArr.fill(3);
emptyArr.fill(2, 0, 1);
emptyArr.fill(4, 1, 4);
console.log(emptyArr);

//// Array.from()

// The Array.from() static method creates a new, shallow-copied Array instance from an array-like or iterable object.
// used on Array Object
const y = Array.from({ length: 7 }, () => 1);
console.log(y);

const z = Array.from({ length: 7 }, (_, i) => i + 1);
console.log(z);

// nodelist to array, now array methods can be applied as well
labelBalance.addEventListener('click', function () {
  const movementsUI = Array.from(
    document.querySelectorAll('.movements__value'),
    el => Number(el.textContent)
  );
  console.log(movementsUI);
});
*/
