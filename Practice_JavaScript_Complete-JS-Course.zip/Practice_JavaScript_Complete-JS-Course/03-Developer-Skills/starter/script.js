// Remember, we're gonna use strict mode in all scripts now!
/*
"use strict";
const c = "90";
console.log(c);
*/

//// Debugging thru console
const measureKelvin = function() {
     const measurement = {
         type: 'temp',
         unit: 'celcius',
         // correct bug
         value: Number( prompt('Degree celcius'))
     };

     // find bug
     console.table(measurement);

    //  console.warn(measurement.value);
    //  console.error(measurement.value);

     const kelvin = measurement.value + 273;
     return kelvin;
}

// A) identify the bug
console.log(measureKelvin());

//// USe debugger
