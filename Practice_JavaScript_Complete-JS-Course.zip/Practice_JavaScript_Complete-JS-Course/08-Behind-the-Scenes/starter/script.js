'use strict';

// console.log(this);   // "window"

/*---------------------*/
// Regular vs Arrow functions

const greeshma ={
    firstName: 'Greeshma',
    birthYear: 2003,
    lastName: 'Reddy',

    calAge: function() {
        this.age = 2021 - this.birthYear;
        console.log(this.age);

        /*
        // Solution 1
        const self = this;  // 'self' or 'that'
        Regular functions inside Object method
        const isMillenial = function () {
            if(this.birthYear >= 1981 && this.birthYear <= 1995)    // 'this' is not accessible in functions of methods
                console.log('Is a millenial');
        }
        */

        /*
        // Solution 2 ✅
        // when 'this' is used in arrow functions, it accesses the parent here, which is 'greeshma' (since it's not method, and doesn't own but inherits it from parent function)
        const isMillenial = () => {
            console.log(this);
            if(this.birthYear >= 1981 && this.birthYear <= 1995)
                console.log('Is a millenial');
            else 
                console.log('not millenial');
        }
        isMillenial();
        */
    },

    // // Arrow method
    // greet: () => {
    //     console.log(this);  // window
    //     console.log( `Hey ${this.firstName}`);  // "Hey undefined"
    // },
}

// greeshma.calAge();
// greeshma.greet();

/* ------------------------------ */
//// Primitives vs. Objects in Practice

// Primmitive types
let lastName = 'Williams';
let oldLastName = lastName;
lastName = 'Davis';

console.log(lastName, oldLastName); // Davis Williams

// Reference objects
const jessica = {
    firstName: 'Jessica',
    lastName: 'Williams',
    age: 27,
}

const marriedJessica = jessica;
// marriedJessica.lastName = 'Davis';

console.log(marriedJessica, jessica);   // both same

    // object value changes in Heap. 'const' doesnt have any affect on heap memory variables
    // but this will give error, since new object alloted altogether 👇, this changes the address in stack itself
// marriedJessica = {}

// Copying objects
    // can be done using Object.assign() method, which merges two objects to create new one
const jessica2 = Object.assign({}, jessica);    // merges empty string and jessica
jessica2.lastName = 'Davis';

console.log('Before Marriage:', jessica);
console.log('After Marriage:', jessica2);
