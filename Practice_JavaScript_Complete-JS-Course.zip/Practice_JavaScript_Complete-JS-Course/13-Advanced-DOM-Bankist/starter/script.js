'use strict';

const modal = document.querySelector('.modal');
const overlay = document.querySelector('.overlay');
const btnCloseModal = document.querySelector('.btn--close-modal');
const btnsOpenModal = document.querySelectorAll('.btn--show-modal');
const btnScrollTo = document.querySelector('.btn--scroll-to');
const section1 = document.querySelector('#section--1');

//////////////////////////////////////////////////////////////////
// ---->----> Modal window
const openModal = function () {
  modal.classList.remove('hidden');
  overlay.classList.remove('hidden');
};

const closeModal = function () {
  modal.classList.add('hidden');
  overlay.classList.add('hidden');
};

for (let i = 0; i < btnsOpenModal.length; i++)
  btnsOpenModal[i].addEventListener('click', openModal);

btnCloseModal.addEventListener('click', closeModal);
overlay.addEventListener('click', closeModal);

document.addEventListener('keydown', function (e) {
  if (e.key === 'Escape' && !modal.classList.contains('hidden')) {
    closeModal();
  }
});

// ---->----> Smooth Scrolling
// NOTE
// ** window.scrollTo(x, y) -> Can be used to scroll up and down. The Values of x & y should be wrt. the top of document and not current position of scrollBar.
// ** Modern way -> Section.scrollIntoView({behaviour: 'smooth'})

btnScrollTo.addEventListener('click', function (e) {
  const s1coords = section1.getBoundingClientRect();
  console.log(s1coords);

  console.log(e.target.getBoundingClientRect());

  console.log('Current scroll (X/Y)', window.pageXOffset, window.pageYOffset);

  console.log(
    'height/width viewport',
    document.documentElement.clientHeight,
    document.documentElement.clientWidth
  );

  // Scrolling
  // window.scrollTo(
  // //    amount already scrolled + scroll left to cover
  //   s1coords.left + window.pageXOffset,
  //   s1coords.top + window.pageYOffset
  // );

  // window.scrollTo({
  //   left: s1coords.left + window.pageXOffset,
  //   top: s1coords.top + window.pageYOffset,
  //   behavior: 'smooth',
  // });

  // Modern scroll way
  section1.scrollIntoView({ behavior: 'smooth' });
});

// ---->----> Page Navigation
// 1. Add event listener to common parent element
// 2. Determine what element originated the event

// * Method 1: This is not very efficient because it create events for each node element
// document.querySelectorAll('.nav__link').forEach(function (el) {
//   el.addEventListener('click', function (e) {
//     e.preventDefault();
//     const id = this.getAttribute('href');
//     console.log(id);
//     document.querySelector(id).scrollIntoView({ behavior: 'smooth' });
//   });
// });

// * Method 2: Using Event Delegation (using the Bubbling up of events)
document.querySelector('.nav__links').addEventListener('click', function (e) {
  e.preventDefault();

  // Matching strategy
  if (e.target.classList.contains('nav__link')) {
    const id = e.target.getAttribute('href');
    console.log(id);
    document.querySelector(id).scrollIntoView({ behavior: 'smooth' });
  }
});

///////////////////////////////////////
///////////////////////////////////////
///////////////////////////////////////
/*
// ---->----> Selecting Elements
console.log(document); // selects the <html></html> content
console.log(document.documentElement);
console.log(document.head);
console.log(document.body);

document.querySelector('.header');
document.querySelector('.section'); // Query Selector gives a NodeList that doesn't update
document.getElementById('section--1');

// whereas "getElementBy..." gives a HTMLcollection, this is a live collection, ie. it reflects changes in the list taken place even after it's formed
// console.log(document.getElementsByClassName("btn"));

const header = document.querySelector('.header');
const allSections = document.querySelectorAll('.section');

document.getElementById('section--1');
const allButtons = document.getElementsByTagName('button');

// console.log(document.getElementsByClassName('btn'));

///////////////////////////////////////
// ---->----> Creating and Inserting elements
/** 
 * NOTE
 * doc.createElement 
 * .classList.add
 * parent.append(ele)
 * parent.prepend(ele)
 * parent.before(ele)
 * parent.after(ele)
---->

const message = document.createElement('div');
message.classList.add('cookie-message');
// message.textContent = "Hello World";
message.innerHTML =
'We use cookied for improved functionality and analytics. <button class="btn btn--close-cookie">Got it!</button>';

// header.prepend(message)  // add just after opening tag <header></header>
header.append(message);
// header.prepend(message.cloneNode(true))   // cloneNode allows duplicating the element

// Using these 👇 both won't duplicate the Element
// header.append(message);
// header.prepend(message);

// header.after(message)  // add after element
// header.before(message) // add before element

document
.querySelector('.btn--close-cookie')
.addEventListener('click', function () {
  message.remove();
  // message.parentElement.removeChild(message);  // old method
});


///////////////////////////////////////
// ---->----> Styles, Attributes, Classes
/**
 * NOTE
 * getComputerStyle(element).__style -> to obtain the style applied on the created Element
 * parseInt -> get Integer part from String
 * parseFloat -> get Float part from String
 * Data Attributes -> used when we need to store data in the UI
 ---->

message.style.background = '#37383d';
message.style.width = '104%';

// console.log(message.style.color);            // No Output -> for Created Elements, only inline styles can be logged (inline-> styles that are manually set)
console.log(message.style.background);          // Output -> rgb(55, 56, 61)

// console.log(getComputedStyle(message));      // -> to display the Styles applied on the Element; this will give list of all styles
console.log(getComputedStyle(message).color);   // rgb(187, 187, 187)
console.log(getComputedStyle(message).height);  // 49px


message.style.height = Number.parseFloat(getComputedStyle(message).height) + 30 + 'px';

//----> CSS Varibles maniputlating
document.documentElement.style.setProperty('--color-primary', 'orangered');

//----> Attributes
const logo = document.querySelector(".nav__logo");
console.log(logo.className);
console.log(logo.alt);
logo.alt = "Beautiful minimalist logo";

//----> Non-standard attributes
console.log(logo.designer);   // these are a little less used attributes, hence show 'undefined'
console.log(logo.getAttribute('designer'));
logo.setAttribute('company', 'Bankist');

console.log(logo.src);                  // gives the local host src
console.log(logo.getAttribute('src'));  // gives the relative src

const link = document.querySelector('.nav__link--btn')
console.log(link.href);
console.log(link.getAttribute('href'));

//----> Data attributes
console.log(logo.dataset.versionNumber);

//----> Classes
logo.classList.add('c', 'j');   // mutiple classes
logo.classList.add('c', 'j');
logo.classList.remove('c', 'j');
logo.classList.toggle('c');
logo.classList.contains('c'); // not includes

// NOTE Don't use 👇, as it overrides other class names
// logo.className('c')

//////////////////////////////////
//---->----> Types of Events and Event Handlers
const h1 = document.querySelector('h1');

const alertH1 = function (e) {
  alert('addEventListener: Great! You are reading the heading :D');
};

h1.addEventListener('mouseenter', alertH1);

setTimeout(() => h1.removeEventListener('mouseenter', alertH1), 3000);

///////////////////////////////////////
//---->----> Event Propagation in Practice
// NOTE 
// * The events are applied during Target phase and Bubbling Phase (not Capturing)
// * target -> the one which triggered the change
// * currentTarget -> the one on which calls/ was triggered (currentTarget == this)
// * e.stopPropagation -> to stop event Bubbling/Capturing further. Try avoid using.
// * .addEventListener(param1, param2, param3) -> the Third parameter is used to use Capture phase (set to 'true')

const randomInt = (min, max) =>
  Math.floor(Math.random() * (max - min + 1) + min);
const randomColor = () =>
  `rgb(${randomInt(0, 255)}, ${randomInt(0, 255)}, ${randomInt(0, 255)})`;

document.querySelector('.nav__link').addEventListener('click', function (e) {
  this.style.backgroundColor = randomColor();
  console.log('Link', e.target, e.currentTarget);

  // Stop Propagation
  // e.stopPropagation();
});

// Parent
document.querySelector('.nav__links').addEventListener('click', function (e) {
  this.style.backgroundColor = randomColor();
  console.log('Container', e.target, e.currentTarget);
});

// Grandparent
document.querySelector('.nav').addEventListener('click', function (e) {
  this.style.backgroundColor = randomColor();
  console.log('Nav', e.target, e.currentTarget);
}, false);

///////////////////////////////////////
// ---->----> DOM Traversing
const h1 = document.querySelector('h1');

// Going Downwards: child
console.log(h1.querySelectorAll(".highlight"));
console.log(h1.childNodes);   // gives nodeList with each element
console.log(h1.children);     // ✅gives HTMLCollection of all children
h1.firstElementChild.style.color = 'orangered';
h1.lastElementChild.style.color = 'white';

// Goind Upwards: parent
console.log(h1.parentElement);    // ✅
console.log(h1.parentNode);

h1.closest('.header').style.backgroundColor = 'var(--color-primary-opacity)'; 

// NOTE 
  // element.closest(selector) -> gives the closest matching parent
  // .closest() is kind of opposite to .querySelector(). QS goes deep down to find the child, whereas 'Closest' goes upwards to find parent

// Going Sideways 
// (direct siblings)
console.log(h1.nextElementSibling);       // ✅
console.log(h1.previousElementSibling);  // ✅

console.log(h1.nextSibling);
console.log(h1.previousSibling);

console.log(h1.parentElement.children); // for all siblings

[...h1.parentElement.children].forEach(function (el) {
  if(el !== h1) el.style.transform = 'scale(0.5)';
});
*/



