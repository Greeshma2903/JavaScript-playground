'use strict';

/** ------------------------------------- 
// DEFAULT PARAMETERS

const bookings = [];
const bookingFlight = function (
  flight,
  numPassenger = 1,
  price = 720 * numPassenger
) {
  const booking = {
    flight,
    numPassenger,
    price,
  };

  bookings.push(booking);
};

bookingFlight('Airbus 320', 3);

console.log(bookings);

// * default parameter can be set in the function prototype itself
// * to set the default value, the parameter on its right should also hve default set;
// function (name = raj, age) --> not allowed
// function (name = raj, age = 10) --> allowed
*/

/** ----------------------------------------- 
// PASSING ARGUMENTS TO FUNCTIONS: PASS BY VALUE

const flight = 'LH239';
const greeshma = {
  name: 'Greeshma',
  passport: 320911298,
};

const checkIn = function (flightNum, passenger) {
  flightNum = 'LH900';
  passenger.name = 'Ms. ' + passenger.name;

};

checkIn(flight, greeshma);
console.log(flight); // unchanged
console.log(greeshma); // changed

// * primitive types don't change, reference types do change : if changed in functions
// * HENCE, donot try to change value of parameters in functions, as it can break a lot of code/logic

/* in JS, parameters are passed by value: 
When we pass a primitive type as an argument on a function, the function makes a copy of the ORIGINAL VALUE, and works with it.

On the other hand, when we pass an object as an argument on a function, the function makes a copy of the REFERENCE that points to the place of the memory where the object is stored. This copy is a value itself, is not a reference. Because all of this, the original object can be modified from inside of a function.

- So, when we pass primitive values, the function works with a value, which is a copy of the original value

- When we pass an object, the function works with a value that address to the

spot where the original object is in the memory (still is not a reference)
*/

/* ---------------------------------------------------
// FUNCTION ACCEPTING CALLBACK FUNCTIONS

// * A callback function is a function that is passed as an argument to another function(higher order), to be “called back” at a later time.

const oneWord = function (str) {
  return str.replaceAll(' ', '').toLowerCase();
};

const upperFirstWord = function (str) {
  const [first, ...others] = str.split(' ');
  return [first.toUpperCase(), ...others].join(' ');
};

// Higher order function
const transformer = function (str, fun) {
  console.log(`Original string: ${str}`);
  console.log(`Transformed string: ${fun(str)}`);
};

transformer('Dal is the best 😋', oneWord);
transformer('Dal is the best 😋', upperFirstWord);

// * Callback functions helps us to implement Abstraction in programming (the ability to hide details)

// Example
const studentMarks = [23, 24, 13, 21, 19];

const studentAvg = function (marks, SumMarks) {
  const sum = SumMarks(marks);
  const avg = sum / marks.length;
  console.log(`Average marks of students is ${avg}`);
};

const SumMarks = function (marks) {
  let sum = 0;
  for (const mark of marks) {
    sum += mark;
  }
  return sum;
};

studentAvg(studentMarks, SumMarks);
*/

/* -------------------------------------- 
// FUNCTIONS RETURNING FUNCTIONS

const greet = function (greeting) {
  return function (name) {
    console.log(`${greeting} ${name}`);
  }
}

// Using arrow functions
// const greet = greeting => name => {
//   console.log(`${greeting} ${name}`);
// };  

const greeter = greet('Hey');
greeter('Jonas');

greet('Hello')('Komali');
*/

/** ------------------------------------------- 
// call AND apply METHOD

const lufthansa = {
  airline: 'Lufthansa airlines',
  iataCode: 'LH',
  booking: [],
  book(flightNum, name) {
    console.log(
      `${name} booked flight on ${this.airline} flight ${this.iataCode}${flightNum}`
    );
    this.booking.push({ flight: `${this.iataCode}${flightNum}`, name });
  },
};

lufthansa.book(236, 'Greeshma');
lufthansa.book(789, 'Komali');

const eurowings = {
  airline: 'Eurowings airline',
  iataCode: 'EW',
  booking: [],
};

const book = lufthansa.book;

// This doesn't work since 'this' doesn't work with functions
// book(239, 'Mother');


// call Method : calls the method of an object, substituting the other object with current object. 'this' now has Object to an point to.
// * SYNTAX:    func.call(context, args...)
book.call(eurowings, 234, 'Greeshma');
book.call(lufthansa, 344, 'Mary Poppins');
console.log(lufthansa);

// for call method, we need to have the SAME property names (in Objects)
const swiss = {
  airline: 'Swiss Airlines',
  iataCode: 'SW',
  booking: [],
};

book.call(swiss, 453, 'Tanmay Patil');

// apply method (instead of args, takes array of args) (isn't used much)
// * SYNTAX:    func.apply(context, array)
const flightDetails = [343, 'Hari'];
book.apply(swiss, flightDetails);
console.log(swiss);

// * but 'apply' method isn't used much, instead:
book.call(eurowings, ...flightDetails);

///////////////////

// .bind() METHOD

// * The JavaScript Function bind() method is used to create a new function. When a function is called, it has its own this keyword set to the provided value, with a given sequence of arguments.

// Instead of using 'call' method, we can use 'bind', where we can assign a function, that points to required Object & hence use that further

const bookLH = lufthansa.book.bind(lufthansa);
const bookSW = book.bind(swiss);
const bookEU = book.bind(eurowings);

bookLH(234, 'Jay');
bookEU(324, 'Mahi');
bookSW(34, 'Uri');

// to preset some arguments, we can bind some arguments as well: 
const bookEU23 = book.bind(eurowings, 38);
bookEU23('Mary Pops');
bookEU23('Bajarangi');

// with Event Listeners
lufthansa.planes = 300;
lufthansa.buyPlane = function () {
  console.log(this);

  this.planes++;
  console.log(this.planes);
};
lufthansa.buyPlane();   // here the 'this' points to the object, wheereas below

// 'this' inside the object called by event handler function, points to the handler that called the object
// document.querySelector(".buy").addEventListener('click', lufthansa.buyPlane);  // 'this' points to the event listener
document
  .querySelector('.buy')
  .addEventListener('click', lufthansa.buyPlane.bind(lufthansa));

// ----> Partial application
const addTax = (rate, value) => value + value * rate;
console.log(addTax(0.1, 300));

const addVAT = addTax.bind(null, 0.23); // sets the default value ('null' here is for the 'this', which is not present and hence not important);
console.log(addVAT(400));

console.log("-------------------");
// using function returning function
const theTax = function (rate, value){
  const tax = value + value * rate;
  console.log(tax);
  return theTax.bind(null, 0.23);
}

const retTax = theTax(0.1, 200);
retTax(100);
*/

/* ---------------------------------------------- 
// CLOSURES ⭐

// A Closure is the closed-over variable environment of the execution context in which the funciton was created, even after the excution context is gone. ➡ A closure is like a backpack that a function carries around wherever it goes. This backpack has all the variables that were present in the environment where the function was created.

// ❗We do NOT have to manually create closures, this is a JavaScript feature that happens automaitcally. We can't even access closed over variables explicitely. A closure is not a tangible JavaScript object(it's just an internal property of a function).

// Closure has PRIORITY over the Scope chain of that function

const secureBooking = function () {
  let passenger = 0;
  return function () {
    passenger++;
    console.log(`${passenger} passengers`);
  };
};

const booker = secureBooking();

// the function is still able to use 'passenger' variable from secureBooking, due to Closure.
booker();
booker();
booker();

// Closure cannot be manually accessed, but we can observe it
console.dir(booker);

//  Example 1
let f;

const g = function() {
  const a = 23;
  f = function () {
    console.log(a * 2);
  }
}
// Re-assigning f function
const h = function (){
  const b = 324;
  f = function () {
    console.log(b * 2);
  }
}
g();
f();
h();
f();

// f closes over first definition. then closes over second definition

// Example 2
const boardPassengers = function(n, wait) {
  const perGroup = n/3;

  setTimeout(function () {
    console.log(`We are now boarding all ${n} passengers`);
    console.log(`There are 3 groups, each with ${perGroup} passengers`);
  }, wait * 1000);

  console.log(`Will start boarding in ${wait}`);
}

const perGroup = 1000; // doesn;t use this since Closure has priotity over scope
boardPassengers(300, 3);

*/

// Immediately Invoked Function Expressions --------------------------------
const runOnce = function() {
  console.log('This will never run again');
};
runOnce();    // can actually run more than once

// IIFE
(function() {
  console.log('This will actually never run again.');
  var isPrivate = 2;
})();         

// console.log(isPrivate); // error: undefined

(() => console.log('This will also never run again.'))();

/*
{
  const a = 10;
  var b = 11;
}

console.log(a); // error: undefined
console.log(b); // no error
*/

// NOTE IIFE was a pattern developed by developers to implement data encapsulation and privacy using Scope. 'var' are variables that can be accessed in global scope even if they are declared inside blocks. Hence, to be able to implement data privacy, IIFE were onw such method. It's use has reduced now since 'const' and 'let' have their scopes according to where they are declared (and 'var' isn't preferred to be used). 